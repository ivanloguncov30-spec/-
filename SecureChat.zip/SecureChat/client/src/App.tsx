import React, { useState, useEffect } from 'react';
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider, useQuery } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import Home from "@/pages/home";
import Register from "@/pages/register";
import Login from "@/pages/login";
import ProfileSetup from "@/pages/profile-setup";
import NotFound from "@/pages/not-found";
import type { User } from "@shared/schema";

type AuthState = 'loading' | 'unauthenticated' | 'needsProfile' | 'authenticated';

function AuthenticatedApp() {
  const [authState, setAuthState] = useState<AuthState>('loading');
  const [showLogin, setShowLogin] = useState(true);
  
  // Check if user is authenticated
  const { data: user, isLoading, error } = useQuery<User>({
    queryKey: ['/api/me'],
    retry: false,
  });
  
  useEffect(() => {
    if (isLoading) {
      setAuthState('loading');
    } else if (error || !user) {
      setAuthState('unauthenticated');
    } else if (!user.isProfileComplete) {
      setAuthState('needsProfile');
    } else {
      setAuthState('authenticated');
    }
  }, [user, isLoading, error]);
  
  const handleAuthSuccess = (needsProfileSetup: boolean) => {
    if (needsProfileSetup) {
      setAuthState('needsProfile');
    } else {
      setAuthState('authenticated');
    }
  };
  
  const handleProfileComplete = () => {
    setAuthState('authenticated');
  };
  
  if (authState === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }
  
  if (authState === 'unauthenticated') {
    if (showLogin) {
      return (
        <Login
          onSuccess={handleAuthSuccess}
          onSwitchToRegister={() => setShowLogin(false)}
        />
      );
    } else {
      return (
        <Register
          onSuccess={() => setAuthState('needsProfile')}
          onSwitchToLogin={() => setShowLogin(true)}
        />
      );
    }
  }
  
  if (authState === 'needsProfile') {
    return <ProfileSetup onComplete={handleProfileComplete} />;
  }
  
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <Toaster />
          <AuthenticatedApp />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
