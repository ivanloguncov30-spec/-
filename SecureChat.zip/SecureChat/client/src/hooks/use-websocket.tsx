import { useEffect, useRef, useCallback, useState } from 'react';
import type { MessageWithSender } from '@shared/schema';

interface WebSocketMessage {
  type: string;
  data?: any;
  userId?: string;
  message?: string;
}

interface UseWebSocketProps {
  userId: string;
  chatId?: string;
  onMessage?: (message: MessageWithSender) => void;
  onUserTyping?: (userId: string) => void;
  onUserStoppedTyping?: (userId: string) => void;
  onUserOnline?: (userId: string) => void;
  onUserOffline?: (userId: string) => void;
}

export function useWebSocket({
  userId,
  chatId,
  onMessage,
  onUserTyping,
  onUserStoppedTyping,
  onUserOnline,
  onUserOffline,
}: UseWebSocketProps) {
  const ws = useRef<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [typingUsers, setTypingUsers] = useState<Set<string>>(new Set());
  
  // Stable references to callbacks
  const onMessageRef = useRef(onMessage);
  const onUserTypingRef = useRef(onUserTyping);
  const onUserStoppedTypingRef = useRef(onUserStoppedTyping);
  const onUserOnlineRef = useRef(onUserOnline);
  const onUserOfflineRef = useRef(onUserOffline);
  
  useEffect(() => {
    onMessageRef.current = onMessage;
    onUserTypingRef.current = onUserTyping;
    onUserStoppedTypingRef.current = onUserStoppedTyping;
    onUserOnlineRef.current = onUserOnline;
    onUserOfflineRef.current = onUserOffline;
  });

  const connect = useCallback(() => {
    if (ws.current?.readyState === WebSocket.OPEN) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    ws.current = new WebSocket(wsUrl);

    ws.current.onopen = () => {
      console.log('WebSocket connected');
      setIsConnected(true);
      
      if (chatId && userId) {
        ws.current?.send(JSON.stringify({
          type: 'join',
          chatId,
          userId,
        }));
      }
    };

    ws.current.onmessage = (event) => {
      try {
        const message: WebSocketMessage = JSON.parse(event.data);
        
        switch (message.type) {
          case 'newMessage':
            onMessageRef.current?.(message.data);
            break;
          case 'userTyping':
            if (message.userId && message.userId !== userId) {
              setTypingUsers(prev => new Set(prev).add(message.userId!));
              onUserTypingRef.current?.(message.userId);
            }
            break;
          case 'userStoppedTyping':
            if (message.userId) {
              setTypingUsers(prev => {
                const newSet = new Set(prev);
                newSet.delete(message.userId!);
                return newSet;
              });
              onUserStoppedTypingRef.current?.(message.userId);
            }
            break;
          case 'userOnline':
            if (message.userId) {
              onUserOnlineRef.current?.(message.userId);
            }
            break;
          case 'userOffline':
            if (message.userId) {
              onUserOfflineRef.current?.(message.userId);
            }
            break;
          case 'error':
            console.error('WebSocket error:', message.message);
            break;
        }
      } catch (error) {
        console.error('Failed to parse WebSocket message:', error);
      }
    };

    ws.current.onclose = () => {
      console.log('WebSocket disconnected');
      setIsConnected(false);
      setTypingUsers(new Set());
    };

    ws.current.onerror = (error) => {
      console.error('WebSocket error:', error);
      setIsConnected(false);
    };
  }, [userId]); // Removed unstable dependencies

  const disconnect = useCallback(() => {
    if (ws.current) {
      ws.current.close();
      ws.current = null;
      setIsConnected(false);
      setTypingUsers(new Set());
    }
  }, []);

  const sendMessage = useCallback((content: string) => {
    if (ws.current?.readyState === WebSocket.OPEN && chatId) {
      ws.current.send(JSON.stringify({
        type: 'message',
        chatId,
        content,
      }));
    }
  }, [chatId]);

  const sendTyping = useCallback(() => {
    if (ws.current?.readyState === WebSocket.OPEN && chatId) {
      ws.current.send(JSON.stringify({
        type: 'typing',
        chatId,
      }));
    }
  }, [chatId]);

  const sendStopTyping = useCallback(() => {
    if (ws.current?.readyState === WebSocket.OPEN && chatId) {
      ws.current.send(JSON.stringify({
        type: 'stopTyping',
        chatId,
      }));
    }
  }, [chatId]);

  useEffect(() => {
    connect();
    return () => disconnect();
  }, [userId]); // Only reconnect when userId changes

  // Rejoin when chatId changes
  useEffect(() => {
    if (ws.current?.readyState === WebSocket.OPEN && chatId && userId) {
      ws.current.send(JSON.stringify({
        type: 'join',
        chatId,
        userId,
      }));
    }
  }, [chatId, userId]);

  return {
    isConnected,
    sendMessage,
    sendTyping,
    sendStopTyping,
    typingUsers,
  };
}
