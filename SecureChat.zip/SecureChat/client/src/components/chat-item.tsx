import React from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import type { ChatWithLastMessage } from '@shared/schema';

interface ChatItemProps {
  chat: ChatWithLastMessage;
  isSelected: boolean;
  onClick: () => void;
  currentUserId: string;
}

export function ChatItem({ chat, isSelected, onClick, currentUserId }: ChatItemProps) {
  const otherUser = chat.members.find(member => member.id !== currentUserId);
  const chatName = chat.isGroup ? chat.name || 'Group Chat' : otherUser?.username || 'Unknown';
  const chatAvatar = chat.isGroup ? chat.avatar : otherUser?.avatar;
  
  const formatTime = (date: Date) => {
    const now = new Date();
    const messageDate = new Date(date);
    const diffInHours = (now.getTime() - messageDate.getTime()) / (1000 * 60 * 60);
    
    if (diffInHours < 24) {
      return messageDate.toLocaleTimeString('en-US', { 
        hour: 'numeric', 
        minute: '2-digit',
        hour12: true 
      });
    } else if (diffInHours < 48) {
      return 'Yesterday';
    } else {
      return messageDate.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric' 
      });
    }
  };

  return (
    <div
      className={`
        p-3 hover:bg-accent cursor-pointer border-b border-border transition-colors
        ${isSelected ? 'bg-accent' : ''}
      `}
      onClick={onClick}
      data-testid={`chat-item-${chat.id}`}
    >
      <div className="flex items-center gap-3">
        <div className="relative">
          <Avatar className="w-12 h-12">
            <AvatarImage src={chatAvatar || undefined} alt={`${chatName} avatar`} />
            <AvatarFallback className="bg-primary text-primary-foreground">
              {chatName.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          {!chat.isGroup && otherUser?.isOnline && (
            <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-background" />
          )}
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between">
            <h3 className="font-medium text-foreground truncate" data-testid={`text-chat-name-${chat.id}`}>
              {chatName}
            </h3>
            {chat.lastMessage && (
              <span className="text-xs text-muted-foreground" data-testid={`text-last-message-time-${chat.id}`}>
                {formatTime(chat.lastMessage.createdAt || new Date())}
              </span>
            )}
          </div>
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground truncate" data-testid={`text-last-message-${chat.id}`}>
              {chat.lastMessage ? (
                <>
                  {chat.lastMessage.senderId === currentUserId ? 'You: ' : ''}
                  {chat.lastMessage.content}
                </>
              ) : (
                'No messages yet'
              )}
            </p>
            {chat.unreadCount > 0 && (
              <Badge 
                className="bg-primary text-primary-foreground text-xs px-2 py-1 rounded-full ml-2"
                data-testid={`badge-unread-count-${chat.id}`}
              >
                {chat.unreadCount}
              </Badge>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
