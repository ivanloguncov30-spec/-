import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Search, UserPlus, Users } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useTranslation } from '@/hooks/useTranslation';
import { apiRequest } from '@/lib/queryClient';
import type { User } from '@shared/schema';

interface NewChatDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onChatCreated: (chatId: string) => void;
}

export default function NewChatDialog({ open, onOpenChange, onChatCreated }: NewChatDialogProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'users' | 'groups'>('users');
  const { t } = useTranslation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Search users
  const { data: searchResults = [], isLoading } = useQuery<User[]>({
    queryKey: ['/api/users/search', searchQuery],
    queryFn: async () => {
      if (searchQuery.length < 2) return [];
      const response = await fetch(`/api/users/search/${encodeURIComponent(searchQuery)}`, {
        credentials: 'include',
      });
      if (!response.ok) {
        throw new Error(`${response.status}: ${response.statusText}`);
      }
      return response.json();
    },
    enabled: searchQuery.length >= 2,
  });

  const createChatMutation = useMutation({
    mutationFn: async (userId: string) => {
      const response = await apiRequest('POST', '/api/chats', {
        participantId: userId,
        isGroup: false,
      });
      return await response.json();
    },
    onSuccess: (data) => {
      toast({
        title: 'Chat Created',
        description: 'New chat has been created',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/chats'] });
      onChatCreated(data.chat.id);
      onOpenChange(false);
      setSearchQuery('');
    },
    onError: (error: any) => {
      toast({
        title: t('somethingWrong'),
        description: error.message || t('tryAgain'),
        variant: 'destructive',
      });
    },
  });

  const createGroupMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/chats', {
        isGroup: true,
        name: 'New Group',
      });
      return await response.json();
    },
    onSuccess: (data) => {
      toast({
        title: 'Group Created',
        description: 'New group has been created',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/chats'] });
      onChatCreated(data.chat.id);
      onOpenChange(false);
    },
    onError: (error: any) => {
      toast({
        title: t('somethingWrong'),
        description: error.message || t('tryAgain'),
        variant: 'destructive',
      });
    },
  });

  const handleStartChat = (userId: string) => {
    createChatMutation.mutate(userId);
  };

  const handleCreateGroup = () => {
    createGroupMutation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md" data-testid="new-chat-dialog">
        <DialogHeader>
          <DialogTitle>Start New Chat</DialogTitle>
          <DialogDescription>
            Search for users or create a group chat
          </DialogDescription>
        </DialogHeader>

        {/* Tabs */}
        <div className="flex border-b border-border">
          <button
            onClick={() => setActiveTab('users')}
            className={`flex-1 flex items-center justify-center gap-2 py-2 px-4 text-sm font-medium border-b-2 transition-colors ${
              activeTab === 'users'
                ? 'border-primary text-primary'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
            data-testid="tab-users"
          >
            <UserPlus className="w-4 h-4" />
            Users
          </button>
          <button
            onClick={() => setActiveTab('groups')}
            className={`flex-1 flex items-center justify-center gap-2 py-2 px-4 text-sm font-medium border-b-2 transition-colors ${
              activeTab === 'groups'
                ? 'border-primary text-primary'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
            data-testid="tab-groups"
          >
            <Users className="w-4 h-4" />
            Groups
          </button>
        </div>

        {activeTab === 'users' && (
          <div className="space-y-4">
            {/* Search Input */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search users by name or username..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="input-user-search"
              />
            </div>

            {/* Search Results */}
            <div className="max-h-80 overflow-y-auto space-y-2">
              {searchQuery.length < 2 && (
                <div className="text-center py-8 text-muted-foreground">
                  <UserPlus className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p>Type at least 2 characters to search for users</p>
                </div>
              )}

              {searchQuery.length >= 2 && isLoading && (
                <div className="text-center py-4">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary mx-auto"></div>
                </div>
              )}

              {searchQuery.length >= 2 && !isLoading && searchResults.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  <UserPlus className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p>No users found</p>
                </div>
              )}

              {searchResults.map((user) => (
                <div
                  key={user.id}
                  className="flex items-center gap-3 p-3 rounded-lg hover:bg-accent cursor-pointer transition-colors"
                  onClick={() => handleStartChat(user.id)}
                  data-testid={`user-result-${user.id}`}
                >
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={user.avatar || undefined} alt={user.username || ''} />
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      {user.firstName?.charAt(0)?.toUpperCase() || '?'}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium truncate">
                      {user.firstName} {user.lastName}
                    </div>
                    {user.username && (
                      <div className="text-sm text-muted-foreground truncate">
                        @{user.username}
                      </div>
                    )}
                  </div>
                  {user.isOnline && (
                    <div className="w-3 h-3 bg-green-500 rounded-full" />
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'groups' && (
          <div className="space-y-4">
            <div className="text-center py-8">
              <Users className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <h3 className="font-medium mb-2">Create a Group Chat</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Start a group conversation with multiple people
              </p>
              <Button
                onClick={handleCreateGroup}
                disabled={createGroupMutation.isPending}
                data-testid="button-create-group"
              >
                {createGroupMutation.isPending ? "Creating..." : "Create Group"}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}