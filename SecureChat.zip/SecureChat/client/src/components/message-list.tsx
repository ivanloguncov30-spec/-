import React, { useEffect, useRef } from 'react';
import { MessageBubble } from './message-bubble';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import type { MessageWithSender } from '@shared/schema';

interface MessageListProps {
  messages: MessageWithSender[];
  currentUserId: string;
  typingUsers: Set<string>;
  typingUsersData: Array<{ id: string; username: string; avatar?: string }>;
}

interface TypingIndicatorProps {
  users: Array<{ id: string; username: string; avatar?: string }>;
}

function TypingIndicator({ users }: TypingIndicatorProps) {
  if (users.length === 0) return null;

  const firstUser = users[0];

  return (
    <div className="flex items-start gap-2 max-w-xs" data-testid="typing-indicator">
      <Avatar className="w-8 h-8 flex-shrink-0">
        <AvatarImage src={firstUser.avatar || undefined} alt={`${firstUser.username} avatar`} />
        <AvatarFallback className="bg-primary text-primary-foreground text-xs">
          {firstUser.username.charAt(0).toUpperCase()}
        </AvatarFallback>
      </Avatar>
      
      <div className="relative bg-muted text-foreground rounded-2xl rounded-bl-md px-4 py-3">
        <div className="flex space-x-1">
          <div className="w-2 h-2 bg-muted-foreground rounded-full animate-pulse" style={{ animationDelay: '0s' }} />
          <div className="w-2 h-2 bg-muted-foreground rounded-full animate-pulse" style={{ animationDelay: '0.2s' }} />
          <div className="w-2 h-2 bg-muted-foreground rounded-full animate-pulse" style={{ animationDelay: '0.4s' }} />
        </div>
      </div>
    </div>
  );
}

export function MessageList({ messages, currentUserId, typingUsers, typingUsersData }: MessageListProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, typingUsers.size]);

  const shouldShowAvatar = (message: MessageWithSender, index: number): boolean => {
    if (message.senderId === currentUserId) return false;
    
    if (index === messages.length - 1) return true;
    
    const nextMessage = messages[index + 1];
    return !nextMessage || nextMessage.senderId !== message.senderId;
  };

  const activeTypingUsers = typingUsersData.filter(user => typingUsers.has(user.id));

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4" data-testid="message-list">
      {messages.length === 0 ? (
        <div className="flex items-center justify-center h-full">
          <p className="text-muted-foreground text-center" data-testid="text-no-messages">
            No messages yet. Start a conversation!
          </p>
        </div>
      ) : (
        messages.map((message, index) => (
          <MessageBubble
            key={message.id}
            message={message}
            isOwn={message.senderId === currentUserId}
            showAvatar={shouldShowAvatar(message, index)}
          />
        ))
      )}
      
      <TypingIndicator users={activeTypingUsers} />
      <div ref={messagesEndRef} />
    </div>
  );
}
