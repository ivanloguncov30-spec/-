import React from 'react';
import { Check, CheckCheck } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import type { MessageWithSender } from '@shared/schema';

interface MessageBubbleProps {
  message: MessageWithSender;
  isOwn: boolean;
  showAvatar: boolean;
}

export function MessageBubble({ message, isOwn, showAvatar }: MessageBubbleProps) {
  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });
  };

  if (isOwn) {
    return (
      <div className="flex items-start gap-2 max-w-xs ml-auto" data-testid={`message-${message.id}`}>
        <div className="relative bg-primary text-primary-foreground rounded-2xl rounded-br-md px-4 py-2">
          <p className="text-sm" data-testid={`text-message-content-${message.id}`}>
            {message.content}
          </p>
          <div className="flex items-center justify-end gap-1 mt-1">
            <span className="text-xs opacity-70" data-testid={`text-message-time-${message.id}`}>
              {formatTime(message.createdAt || new Date())}
            </span>
            {message.isRead ? (
              <CheckCheck className="w-3 h-3 opacity-70" data-testid={`icon-message-read-${message.id}`} />
            ) : (
              <Check className="w-3 h-3 opacity-70" data-testid={`icon-message-sent-${message.id}`} />
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-start gap-2 max-w-xs" data-testid={`message-${message.id}`}>
      {showAvatar ? (
        <Avatar className="w-8 h-8 flex-shrink-0">
          <AvatarImage src={message.sender.avatar || undefined} alt={`${message.sender.username} avatar`} />
          <AvatarFallback className="bg-primary text-primary-foreground text-xs">
            {message.sender.username.charAt(0).toUpperCase()}
          </AvatarFallback>
        </Avatar>
      ) : (
        <div className="w-8 h-8 flex-shrink-0" />
      )}
      
      <div className="relative bg-muted text-foreground rounded-2xl rounded-bl-md px-4 py-2">
        <p className="text-sm" data-testid={`text-message-content-${message.id}`}>
          {message.content}
        </p>
        <span className="text-xs text-muted-foreground mt-1 block" data-testid={`text-message-time-${message.id}`}>
          {formatTime(message.createdAt || new Date())}
        </span>
      </div>
    </div>
  );
}
