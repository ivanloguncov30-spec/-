import React from 'react';
import { Phone, Video, Info, Menu } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import type { ChatWithLastMessage, User } from '@shared/schema';

interface ChatHeaderProps {
  chat: ChatWithLastMessage | null;
  currentUserId: string;
  onToggleSidebar: () => void;
}

export function ChatHeader({ chat, currentUserId, onToggleSidebar }: ChatHeaderProps) {
  if (!chat) {
    return (
      <div className="bg-background border-b border-border p-4 flex items-center">
        <Button
          variant="ghost"
          size="icon"
          onClick={onToggleSidebar}
          className="md:hidden mr-3"
          data-testid="button-toggle-sidebar"
        >
          <Menu className="h-5 w-5 text-muted-foreground" />
        </Button>
        <span className="text-muted-foreground" data-testid="text-no-chat-selected">
          Select a chat to start messaging
        </span>
      </div>
    );
  }

  const otherUser = chat.members.find(member => member.id !== currentUserId);
  const chatName = chat.isGroup ? chat.name || 'Group Chat' : otherUser?.username || 'Unknown';
  const chatAvatar = chat.isGroup ? chat.avatar : otherUser?.avatar;
  
  const getStatusText = () => {
    if (chat.isGroup) {
      return `${chat.members.length} members`;
    }
    
    if (otherUser?.isOnline) {
      return 'online';
    }
    
    if (otherUser?.lastSeen) {
      const now = new Date();
      const lastSeen = new Date(otherUser.lastSeen);
      const diffInMinutes = (now.getTime() - lastSeen.getTime()) / (1000 * 60);
      
      if (diffInMinutes < 60) {
        return `last seen ${Math.floor(diffInMinutes)} minutes ago`;
      } else if (diffInMinutes < 1440) {
        return `last seen ${Math.floor(diffInMinutes / 60)} hours ago`;
      } else {
        return `last seen ${Math.floor(diffInMinutes / 1440)} days ago`;
      }
    }
    
    return 'offline';
  };

  return (
    <div className="bg-background border-b border-border p-4 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <Button
          variant="ghost"
          size="icon"
          onClick={onToggleSidebar}
          className="md:hidden"
          data-testid="button-toggle-sidebar"
        >
          <Menu className="h-5 w-5 text-muted-foreground" />
        </Button>
        
        <div className="relative">
          <Avatar className="w-10 h-10">
            <AvatarImage src={chatAvatar || undefined} alt={`${chatName} avatar`} />
            <AvatarFallback className="bg-primary text-primary-foreground">
              {chatName.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          {!chat.isGroup && otherUser?.isOnline && (
            <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-background" />
          )}
        </div>
        
        <div>
          <h2 className="font-semibold text-foreground" data-testid="text-chat-name">
            {chatName}
          </h2>
          <p className="text-sm text-muted-foreground" data-testid="text-chat-status">
            {getStatusText()}
          </p>
        </div>
      </div>
      
      <div className="flex items-center gap-2">
        <Button
          variant="ghost"
          size="icon"
          className="rounded-lg"
          data-testid="button-video-call"
        >
          <Video className="h-5 w-5 text-muted-foreground" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="rounded-lg"
          data-testid="button-voice-call"
        >
          <Phone className="h-5 w-5 text-muted-foreground" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="rounded-lg"
          data-testid="button-chat-info"
        >
          <Info className="h-5 w-5 text-muted-foreground" />
        </Button>
      </div>
    </div>
  );
}
