import React, { useState } from 'react';
import { Search, Moon, Sun, X, Menu, Plus, Settings } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useTheme } from './theme-provider';
import { ChatItem } from './chat-item';
import type { ChatWithLastMessage } from '@shared/schema';

interface SidebarProps {
  chats: ChatWithLastMessage[];
  selectedChatId: string | null;
  onSelectChat: (chatId: string) => void;
  onNewChat: () => void;
  onSettings: () => void;
  isOpen: boolean;
  onToggle: () => void;
  currentUserId: string;
}

export function Sidebar({ 
  chats, 
  selectedChatId, 
  onSelectChat, 
  onNewChat,
  onSettings,
  isOpen, 
  onToggle,
  currentUserId 
}: SidebarProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const { theme, toggleTheme } = useTheme();

  const filteredChats = chats.filter(chat => {
    const chatName = chat.isGroup 
      ? chat.name || 'Group Chat'
      : chat.members.find(m => m.id !== currentUserId)?.username || 'Unknown';
    
    return chatName.toLowerCase().includes(searchQuery.toLowerCase()) ||
           chat.lastMessage?.content.toLowerCase().includes(searchQuery.toLowerCase());
  });

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-10 md:hidden"
          onClick={onToggle}
          data-testid="sidebar-overlay"
        />
      )}
      
      {/* Sidebar */}
      <div className={`
        w-80 bg-secondary border-r border-border flex flex-col
        transition-transform duration-300 ease-in-out
        md:relative absolute left-0 top-0 h-full z-20
        ${isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
      `} data-testid="sidebar">
        {/* Header */}
        <div className="p-4 border-b border-border">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-xl font-semibold text-foreground">Messages</h1>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={onNewChat}
                className="rounded-lg"
                data-testid="button-new-chat"
              >
                <Plus className="h-5 w-5 text-muted-foreground" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={onSettings}
                className="rounded-lg"
                data-testid="button-settings"
              >
                <Settings className="h-5 w-5 text-muted-foreground" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                className="rounded-lg"
                data-testid="button-theme-toggle"
              >
                {theme === 'dark' ? 
                  <Sun className="h-5 w-5 text-muted-foreground" /> : 
                  <Moon className="h-5 w-5 text-muted-foreground" />
                }
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={onToggle}
                className="rounded-lg md:hidden"
                data-testid="button-close-sidebar"
              >
                <X className="h-5 w-5 text-muted-foreground" />
              </Button>
            </div>
          </div>
          
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Search messages..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-background"
              data-testid="input-search"
            />
          </div>
        </div>

        {/* Chat List */}
        <div className="flex-1 overflow-y-auto" data-testid="chat-list">
          {filteredChats.length > 0 ? (
            filteredChats.map(chat => (
              <ChatItem
                key={chat.id}
                chat={chat}
                isSelected={selectedChatId === chat.id}
                onClick={() => {
                  onSelectChat(chat.id);
                  if (window.innerWidth < 768) {
                    onToggle();
                  }
                }}
                currentUserId={currentUserId}
              />
            ))
          ) : (
            <div className="p-4 text-center text-muted-foreground" data-testid="text-no-chats">
              No chats found
            </div>
          )}
        </div>
      </div>
    </>
  );
}
