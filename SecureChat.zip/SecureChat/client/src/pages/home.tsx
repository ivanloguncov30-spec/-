import React, { useState, useCallback } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Sidebar } from '@/components/sidebar';
import { ChatHeader } from '@/components/chat-header';
import { MessageList } from '@/components/message-list';
import { MessageInput } from '@/components/message-input';
import { useWebSocket } from '@/hooks/use-websocket';
import NewChatDialog from '@/components/new-chat-dialog';
import Settings from '@/pages/settings';
import type { ChatWithLastMessage, MessageWithSender, User } from '@shared/schema';
import { useTranslation } from '@/hooks/useTranslation';

export default function Home() {
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [messages, setMessages] = useState<MessageWithSender[]>([]);
  const [showSettings, setShowSettings] = useState(false);
  const [showNewChat, setShowNewChat] = useState(false);
  const queryClient = useQueryClient();
  const { t } = useTranslation();

  // Fetch current user
  const { data: currentUser } = useQuery<User>({
    queryKey: ['/api/me'],
  });

  // Fetch user chats
  const { data: chats = [], isLoading: chatsLoading } = useQuery<ChatWithLastMessage[]>({
    queryKey: ['/api/chats', 'currentUser'],
    enabled: !!currentUser?.id,
  });

  // Fetch messages for selected chat
  const { data: chatMessages = [], isLoading: messagesLoading } = useQuery<MessageWithSender[]>({
    queryKey: ['/api/chats', selectedChatId, 'messages'],
    enabled: !!selectedChatId,
  });

  // Get typing users data
  const selectedChat = chats.find(chat => chat.id === selectedChatId);
  const typingUsersData = selectedChat?.members?.filter(member => member.id !== currentUser?.id).map(member => ({
    id: member.id,
    username: member.username,
    avatar: member.avatar || undefined
  })) || [];

  // WebSocket connection
  const {
    isConnected,
    sendMessage,
    sendTyping,
    sendStopTyping,
    typingUsers,
  } = useWebSocket({
    userId: currentUser?.id || '',
    chatId: selectedChatId || undefined,
    onMessage: (newMessage) => {
      setMessages(prev => [...prev, newMessage]);
      
      // Invalidate chats to update last message and unread count
      queryClient.invalidateQueries({ queryKey: ['/api/chats', 'currentUser'] });
    },
  });

  // Update messages when chat messages change
  React.useEffect(() => {
    if (JSON.stringify(messages) !== JSON.stringify(chatMessages)) {
      setMessages(chatMessages);
    }
  }, [chatMessages, messages]);

  const handleSelectChat = useCallback((chatId: string) => {
    setSelectedChatId(chatId);
    
    // Mark messages as read
    if (chatId && currentUser?.id) {
      fetch(`/api/chats/${chatId}/read`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id }),
      }).then(() => {
        // Invalidate chats to update unread count
        queryClient.invalidateQueries({ queryKey: ['/api/chats', 'currentUser'] });
      }).catch(err => console.error('Failed to mark messages as read:', err));
    }
  }, [currentUser?.id, queryClient]);

  const handleSendMessage = useCallback((content: string) => {
    if (selectedChatId && isConnected) {
      sendMessage(content);
    }
  }, [selectedChatId, isConnected, sendMessage]);

  const handleLogout = useCallback(() => {
    window.location.href = '/api/auth/logout';
  }, []);

  const handleChatCreated = useCallback((chatId: string) => {
    setSelectedChatId(chatId);
    setShowNewChat(false);
    // Refresh chats
    queryClient.invalidateQueries({ queryKey: ['/api/chats', 'currentUser'] });
  }, [queryClient]);

  if (chatsLoading || !currentUser) {
    return (
      <div className="h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">{t('loading') || 'Loading...'}</p>
        </div>
      </div>
    );
  }

  if (showSettings) {
    return (
      <Settings 
        onBack={() => setShowSettings(false)}
        onLogout={handleLogout}
      />
    );
  }

  return (
    <div className="flex h-screen bg-background" data-testid="home-page">
      <Sidebar
        chats={chats}
        selectedChatId={selectedChatId}
        onSelectChat={handleSelectChat}
        onNewChat={() => setShowNewChat(true)}
        onSettings={() => setShowSettings(true)}
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
        currentUserId={currentUser.id}
      />
      
      <div className="flex-1 flex flex-col">
        <ChatHeader
          chat={selectedChat || null}
          currentUserId={currentUser.id}
          onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
        />
        
        {selectedChatId ? (
          <>
            {messagesLoading ? (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary mx-auto mb-2"></div>
                  <p className="text-sm text-muted-foreground">{t('loading') || 'Loading messages...'}</p>
                </div>
              </div>
            ) : (
              <MessageList
                messages={messages}
                currentUserId={currentUser.id}
                typingUsers={typingUsers}
                typingUsersData={typingUsersData}
              />
            )}
            
            <MessageInput
              onSendMessage={handleSendMessage}
              onTyping={sendTyping}
              onStopTyping={sendStopTyping}
              disabled={!isConnected}
            />
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center" data-testid="text-select-chat">
              <h2 className="text-2xl font-semibold text-foreground mb-2">{t('welcome')}</h2>
              <p className="text-muted-foreground">{t('selectChat')}</p>
            </div>
          </div>
        )}
      </div>

      <NewChatDialog
        open={showNewChat}
        onOpenChange={setShowNewChat}
        onChatCreated={handleChatCreated}
      />
    </div>
  );
}