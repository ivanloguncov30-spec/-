# Telegram-Style Real-Time Messaging App

## Overview

This is a modern real-time messaging application built with a Telegram-like interface. The app features instant messaging, WebSocket-powered real-time communication, typing indicators, online status tracking, and both individual and group chat capabilities. The application follows a full-stack architecture with a React frontend, Express backend, and PostgreSQL database integration using Drizzle ORM.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The frontend is built with React and TypeScript, utilizing a modern component-based architecture:

- **UI Framework**: React with TypeScript for type safety and better developer experience
- **Styling**: Tailwind CSS with shadcn/ui component library for consistent, accessible UI components
- **State Management**: React Query (TanStack Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Real-time Communication**: WebSocket integration for instant messaging and live updates
- **Theme Support**: Custom theme provider with light/dark mode support
- **PWA Features**: Progressive Web App capabilities with service worker support

### Backend Architecture
The backend follows a RESTful API design with WebSocket support:

- **Server Framework**: Express.js with TypeScript for the HTTP server
- **Real-time Communication**: WebSocket Server (ws library) for instant messaging, typing indicators, and presence updates
- **Development Setup**: Vite integration for hot module replacement and development server
- **Error Handling**: Centralized error handling middleware with proper status codes
- **Logging**: Request/response logging with performance metrics

### Data Storage Solutions
The application uses a PostgreSQL database with Drizzle ORM:

- **Database**: PostgreSQL with Neon Database integration for cloud hosting
- **ORM**: Drizzle ORM for type-safe database operations and migrations
- **Schema Design**: Relational schema with users, chats, chat members, and messages tables
- **Development Storage**: In-memory storage implementation for development and testing
- **Session Management**: PostgreSQL session store using connect-pg-simple

### Database Schema
The core entities include:
- **Users**: User profiles with online status, avatars, and timestamps
- **Chats**: Support for both individual and group conversations
- **Chat Members**: Junction table managing user participation in chats
- **Messages**: Message content with sender information, read status, and metadata

### Authentication and Authorization
Currently implements a simplified authentication system:
- **Session-based**: Uses Express sessions for user authentication
- **User Management**: Basic user creation and profile management
- **Access Control**: Chat member verification for message access

### WebSocket Integration
Real-time features powered by WebSocket connections:
- **Connection Management**: Handles client connections with room-based message routing
- **Message Broadcasting**: Instant message delivery to chat participants
- **Typing Indicators**: Real-time typing status updates
- **Presence System**: Online/offline status tracking
- **Chat Rooms**: Organized message routing based on chat IDs

### Development and Build Process
The project uses a modern development stack:
- **Build Tool**: Vite for fast development and optimized production builds
- **TypeScript**: Full TypeScript support across frontend and backend
- **Hot Reload**: Development server with automatic reload on changes
- **Code Organization**: Monorepo structure with shared types between client and server
- **Path Aliases**: Simplified imports using TypeScript path mapping

## External Dependencies

### Database Services
- **Neon Database**: PostgreSQL-compatible serverless database for production
- **Drizzle Kit**: Database migration and schema management tool

### UI and Styling
- **shadcn/ui**: Pre-built, accessible React components based on Radix UI
- **Radix UI**: Headless UI primitives for complex interactive components
- **Tailwind CSS**: Utility-first CSS framework for styling
- **Lucide React**: Icon library for consistent iconography

### Real-time Communication
- **WebSocket (ws)**: Native WebSocket implementation for real-time features
- **TanStack React Query**: Server state management and caching

### Development Tools
- **Vite**: Build tool and development server with React plugin support
- **TypeScript**: Static type checking and enhanced developer experience
- **ESBuild**: Fast bundling for production builds

### Additional Libraries
- **React Hook Form**: Form handling with validation
- **Zod**: Schema validation for type-safe data handling
- **Date-fns**: Date manipulation and formatting utilities
- **Wouter**: Lightweight routing library for React
- **Class Variance Authority**: Utility for managing component variants