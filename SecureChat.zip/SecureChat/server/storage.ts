import { type User, type InsertUser, type RegisterUser, type ProfileSetup, type Chat, type InsertChat, type Message, type InsertMessage, type ChatMember, type InsertChatMember, type ChatWithLastMessage, type MessageWithSender } from "@shared/schema";
import { randomUUID } from "crypto";
import { db } from "./db";
import { users, chats, messages, chatMembers } from "@shared/schema";
import { eq, desc, and, sql } from "drizzle-orm";
import bcrypt from "bcrypt";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserOnlineStatus(id: string, isOnline: boolean): Promise<void>;
  searchUsers(query: string, currentUserId?: string): Promise<User[]>;
  
  // Authentication
  registerUser(data: RegisterUser): Promise<User>;
  setupProfile(userId: string, profile: ProfileSetup): Promise<User>;
  authenticateUser(email: string, password: string): Promise<User | null>;
  
  // Chats
  getChat(id: string): Promise<Chat | undefined>;
  createChat(chat: InsertChat): Promise<Chat>;
  getUserChats(userId: string): Promise<ChatWithLastMessage[]>;
  
  // Chat Members
  addChatMember(member: InsertChatMember): Promise<ChatMember>;
  getChatMembers(chatId: string): Promise<User[]>;
  
  // Messages
  getMessage(id: string): Promise<Message | undefined>;
  createMessage(message: InsertMessage): Promise<MessageWithSender>;
  getChatMessages(chatId: string, limit?: number, offset?: number): Promise<MessageWithSender[]>;
  markMessagesAsRead(chatId: string, userId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  private passwordHashes: Map<string, string> = new Map(); // Temporary storage for demo

  constructor() {
    // No seed data needed for database implementation
  }

  async getUser(id: string): Promise<User | undefined> {
    try {
      const [user] = await db.select().from(users).where(eq(users.id, id));
      return user;
    } catch (error) {
      console.error('Error getting user:', error);
      return undefined;
    }
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    try {
      const [user] = await db.select().from(users).where(eq(users.email, email));
      return user;
    } catch (error) {
      console.error('Error getting user by email:', error);
      return undefined;
    }
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    try {
      const [user] = await db
        .insert(users)
        .values({
          ...insertUser,
          avatar: insertUser.avatar || null,
          isOnline: false,
          lastSeen: new Date(),
          createdAt: new Date(),
          updatedAt: new Date(),
        })
        .returning();
      return user;
    } catch (error) {
      console.error('Error creating user:', error);
      throw error;
    }
  }

  async registerUser(data: RegisterUser): Promise<User> {
    try {
      // Hash password
      const passwordHash = await bcrypt.hash(data.password, 10);
      
      // Create user
      const [user] = await db
        .insert(users)
        .values({
          email: data.email,
          isOnline: false,
          isProfileComplete: false,
          lastSeen: new Date(),
          createdAt: new Date(),
          updatedAt: new Date(),
        })
        .returning();

      // Store password hash temporarily (in production, use a proper auth system)
      this.passwordHashes.set(user.id, passwordHash);
      
      return user;
    } catch (error) {
      console.error('Error registering user:', error);
      throw error;
    }
  }

  async setupProfile(userId: string, profile: ProfileSetup): Promise<User> {
    try {
      const [user] = await db
        .update(users)
        .set({
          ...profile,
          isProfileComplete: true,
          updatedAt: new Date(),
        })
        .where(eq(users.id, userId))
        .returning();
      
      if (!user) {
        throw new Error('User not found');
      }
      
      return user;
    } catch (error) {
      console.error('Error setting up profile:', error);
      throw error;
    }
  }

  async authenticateUser(email: string, password: string): Promise<User | null> {
    try {
      const user = await this.getUserByEmail(email);
      if (!user) return null;

      const passwordHash = this.passwordHashes.get(user.id);
      if (!passwordHash) return null;

      const isValid = await bcrypt.compare(password, passwordHash);
      return isValid ? user : null;
    } catch (error) {
      console.error('Error authenticating user:', error);
      return null;
    }
  }

  async updateUserOnlineStatus(id: string, isOnline: boolean): Promise<void> {
    try {
      await db
        .update(users)
        .set({
          isOnline,
          lastSeen: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(users.id, id));
    } catch (error) {
      console.error('Error updating user online status:', error);
    }
  }

  async getChat(id: string): Promise<Chat | undefined> {
    try {
      const [chat] = await db.select().from(chats).where(eq(chats.id, id));
      return chat;
    } catch (error) {
      console.error('Error getting chat:', error);
      return undefined;
    }
  }

  async createChat(insertChat: InsertChat): Promise<Chat> {
    try {
      const [chat] = await db
        .insert(chats)
        .values({
          ...insertChat,
          name: insertChat.name || null,
          isGroup: insertChat.isGroup || false,
          avatar: insertChat.avatar || null,
          createdAt: new Date(),
          updatedAt: new Date(),
        })
        .returning();
      return chat;
    } catch (error) {
      console.error('Error creating chat:', error);
      throw error;
    }
  }

  async getUserChats(userId: string): Promise<ChatWithLastMessage[]> {
    try {
      // For simplicity, return empty array for now
      // This would require complex joins in a real implementation
      return [];
    } catch (error) {
      console.error('Error getting user chats:', error);
      return [];
    }
  }

  async addChatMember(insertMember: InsertChatMember): Promise<ChatMember> {
    try {
      const [member] = await db
        .insert(chatMembers)
        .values({
          ...insertMember,
          joinedAt: new Date(),
        })
        .returning();
      return member;
    } catch (error) {
      console.error('Error adding chat member:', error);
      throw error;
    }
  }

  async getChatMembers(chatId: string): Promise<User[]> {
    try {
      const members = await db
        .select()
        .from(users)
        .innerJoin(chatMembers, eq(users.id, chatMembers.userId))
        .where(eq(chatMembers.chatId, chatId));
      
      return members.map(m => m.users);
    } catch (error) {
      console.error('Error getting chat members:', error);
      return [];
    }
  }

  async getMessage(id: string): Promise<Message | undefined> {
    try {
      const [message] = await db.select().from(messages).where(eq(messages.id, id));
      return message;
    } catch (error) {
      console.error('Error getting message:', error);
      return undefined;
    }
  }

  async createMessage(insertMessage: InsertMessage): Promise<MessageWithSender> {
    try {
      const [message] = await db
        .insert(messages)
        .values({
          ...insertMessage,
          messageType: insertMessage.messageType || "text",
          isRead: insertMessage.isRead || false,
          createdAt: new Date(),
        })
        .returning();
      
      const sender = await this.getUser(message.senderId);
      if (!sender) {
        throw new Error('Sender not found');
      }
      
      return { ...message, sender };
    } catch (error) {
      console.error('Error creating message:', error);
      throw error;
    }
  }

  async getChatMessages(chatId: string, limit = 50, offset = 0): Promise<MessageWithSender[]> {
    try {
      const messageList = await db
        .select()
        .from(messages)
        .innerJoin(users, eq(messages.senderId, users.id))
        .where(eq(messages.chatId, chatId))
        .orderBy(messages.createdAt)
        .limit(limit)
        .offset(offset);
      
      return messageList.map(m => ({
        ...m.messages,
        sender: m.users
      }));
    } catch (error) {
      console.error('Error getting chat messages:', error);
      return [];
    }
  }

  async markMessagesAsRead(chatId: string, userId: string): Promise<void> {
    try {
      await db
        .update(messages)
        .set({ isRead: true })
        .where(
          and(
            eq(messages.chatId, chatId),
            eq(messages.senderId, userId)
          )
        );
    } catch (error) {
      console.error('Error marking messages as read:', error);
    }
  }

  // Search users by name or username, excluding current user
  async searchUsers(query: string, currentUserId?: string): Promise<User[]> {
    if (!query || query.length < 2) {
      return [];
    }
    
    try {
      const searchPattern = `%${query.toLowerCase()}%`;
      const usersResult = await db
        .select()
        .from(users)
        .where(
          and(
            currentUserId ? sql`${users.id} != ${currentUserId}` : sql`true`,
            sql`(
              LOWER(COALESCE(${users.firstName}, '')) LIKE ${searchPattern} OR
              LOWER(COALESCE(${users.lastName}, '')) LIKE ${searchPattern} OR
              LOWER(COALESCE(${users.username}, '')) LIKE ${searchPattern}
            )`
          )
        )
        .limit(20);
      
      return usersResult;
    } catch (error) {
      console.error('Error searching users:', error);
      return [];
    }
  }
}

export const storage = new DatabaseStorage();