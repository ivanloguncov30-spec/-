import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertMessageSchema, registerUserSchema, profileSetupSchema, type MessageWithSender, type User } from "@shared/schema";
import { z } from "zod";
import session from "express-session";
import connectPg from "connect-pg-simple";

// Extend Express Request type to include session
declare module "express-session" {
  interface SessionData {
    userId: string;
  }
}

interface AuthenticatedRequest extends Request {
  session: session.Session & Partial<session.SessionData> & {
    userId?: string;
  };
}

interface WSMessage {
  type: 'join' | 'leave' | 'message' | 'typing' | 'stopTyping';
  chatId?: string;
  userId?: string;
  content?: string;
  data?: any;
}

interface ConnectedClient {
  ws: WebSocket;
  userId?: string;
  chatId?: string;
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Session configuration
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  const pgStore = connectPg(session);
  const sessionStore = new pgStore({
    conString: process.env.DATABASE_URL,
    createTableIfMissing: true,
    ttl: sessionTtl,
  });
  
  app.use(session({
    secret: process.env.SESSION_SECRET || 'dev-secret-key',
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: false, // Set to true in production with HTTPS
      maxAge: sessionTtl,
    },
  }));
  
  const clients = new Map<WebSocket, ConnectedClient>();
  const chatRooms = new Map<string, Set<WebSocket>>();

  // WebSocket connection handling
  wss.on('connection', (ws: WebSocket) => {
    console.log('New WebSocket connection');
    clients.set(ws, { ws });

    ws.on('message', async (data: Buffer) => {
      try {
        const message: WSMessage = JSON.parse(data.toString());
        const client = clients.get(ws);
        
        if (!client) return;

        switch (message.type) {
          case 'join':
            if (message.chatId && message.userId) {
              client.userId = message.userId;
              client.chatId = message.chatId;
              
              if (!chatRooms.has(message.chatId)) {
                chatRooms.set(message.chatId, new Set());
              }
              chatRooms.get(message.chatId)!.add(ws);
              
              // Update user online status
              await storage.updateUserOnlineStatus(message.userId, true);
              
              // Notify others in chat about user joining
              broadcastToChat(message.chatId, {
                type: 'userOnline',
                userId: message.userId
              }, ws);
            }
            break;

          case 'message':
            if (message.chatId && message.content && client.userId) {
              try {
                const validatedMessage = insertMessageSchema.parse({
                  chatId: message.chatId,
                  senderId: client.userId,
                  content: message.content,
                  messageType: 'text',
                  isRead: false,
                });
                
                const newMessage = await storage.createMessage(validatedMessage);
                
                // Broadcast message to all clients in the chat
                broadcastToChat(message.chatId, {
                  type: 'newMessage',
                  data: newMessage
                });
              } catch (error) {
                ws.send(JSON.stringify({
                  type: 'error',
                  message: 'Invalid message format'
                }));
              }
            }
            break;

          case 'typing':
            if (message.chatId && client.userId) {
              broadcastToChat(message.chatId, {
                type: 'userTyping',
                userId: client.userId
              }, ws);
            }
            break;

          case 'stopTyping':
            if (message.chatId && client.userId) {
              broadcastToChat(message.chatId, {
                type: 'userStoppedTyping',
                userId: client.userId
              }, ws);
            }
            break;
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
        ws.send(JSON.stringify({
          type: 'error',
          message: 'Invalid message format'
        }));
      }
    });

    ws.on('close', async () => {
      const client = clients.get(ws);
      if (client?.userId && client?.chatId) {
        // Update user offline status
        await storage.updateUserOnlineStatus(client.userId, false);
        
        // Remove from chat room
        chatRooms.get(client.chatId)?.delete(ws);
        
        // Notify others about user going offline
        broadcastToChat(client.chatId, {
          type: 'userOffline',
          userId: client.userId
        }, ws);
      }
      clients.delete(ws);
    });
  });

  function broadcastToChat(chatId: string, message: any, excludeWs?: WebSocket) {
    const chatClients = chatRooms.get(chatId);
    if (chatClients) {
      chatClients.forEach(clientWs => {
        if (clientWs !== excludeWs && clientWs.readyState === WebSocket.OPEN) {
          clientWs.send(JSON.stringify(message));
        }
      });
    }
  }

  // Authentication middleware
  const requireAuth = (req: AuthenticatedRequest, res: any, next: any) => {
    if (!req.session.userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    next();
  };
  
  // Authentication routes
  app.post('/api/auth/register', async (req, res) => {
    try {
      const validatedData = registerUserSchema.parse(req.body);
      const user = await storage.registerUser(validatedData);
      
      req.session.userId = user.id;
      res.json({ user, needsProfileSetup: true });
    } catch (error: any) {
      res.status(400).json({ error: error.message || 'Registration failed' });
    }
  });
  
  app.post('/api/auth/setup-profile', requireAuth, async (req, res) => {
    try {
      const validatedData = profileSetupSchema.parse(req.body);
      const user = await storage.setupProfile(req.session.userId, validatedData);
      
      res.json({ user });
    } catch (error: any) {
      console.error('Error setting up profile:', error);
      if (error.code === '23505' && error.constraint === 'users_username_unique') {
        res.status(400).json({ error: 'Username already taken. Please choose a different username.' });
      } else {
        res.status(400).json({ error: error.message || 'Profile setup failed' });
      }
    }
  });
  
  app.post('/api/auth/login', async (req, res) => {
    try {
      const { email, password } = req.body;
      const user = await storage.authenticateUser(email, password);
      
      if (!user) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }
      
      req.session.userId = user.id;
      res.json({ user, needsProfileSetup: !user.isProfileComplete });
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Login failed' });
    }
  });
  
  app.post('/api/auth/logout', (req, res) => {
    req.session.destroy(() => {
      res.json({ success: true });
    });
  });
  
  // Get current user
  app.get('/api/me', requireAuth, async (req, res) => {
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      res.json(user);
    } catch (error) {
      console.error('Error fetching user:', error);
      res.status(500).json({ error: 'Failed to fetch user' });
    }
  });
  
  // REST API routes
  
  // Search users
  app.get('/api/users/search/:query', requireAuth, async (req, res) => {
    try {
      const query = req.params.query;
      if (query.length < 2) {
        return res.json([]);
      }
      
      const users = await storage.searchUsers(query, req.session.userId);
      res.json(users);
    } catch (error) {
      console.error('Error searching users:', error);
      res.status(500).json({ error: 'Failed to search users' });
    }
  });
  
  // Update profile
  app.put('/api/profile', requireAuth, async (req, res) => {
    try {
      const validatedData = profileSetupSchema.parse(req.body);
      const user = await storage.setupProfile(req.session.userId, validatedData);
      res.json({ user });
    } catch (error: any) {
      console.error('Error updating profile:', error);
      if (error.code === '23505' && error.constraint === 'users_username_unique') {
        res.status(400).json({ error: 'Username already taken. Please choose a different username.' });
      } else {
        res.status(400).json({ error: error.message || 'Profile update failed' });
      }
    }
  });

  // Create a new chat
  app.post('/api/chats', requireAuth, async (req, res) => {
    try {
      const { participantId, isGroup, name } = req.body;
      const userId = req.session.userId;
      
      if (isGroup) {
        // Create group chat
        const chat = await storage.createChat({
          name: name || 'New Group',
          isGroup: true,
        });
        
        // Add current user as member
        await storage.addChatMember({
          chatId: chat.id,
          userId: userId,
          role: 'admin',
        });
        
        res.json({ chat });
      } else {
        // Create private chat
        if (!participantId) {
          return res.status(400).json({ error: 'Participant ID is required' });
        }
        
        const chat = await storage.createChat({
          isGroup: false,
        });
        
        // Add both users as members
        await storage.addChatMember({
          chatId: chat.id,
          userId: userId,
          role: 'member',
        });
        
        await storage.addChatMember({
          chatId: chat.id,
          userId: participantId,
          role: 'member',
        });
        
        res.json({ chat });
      }
    } catch (error) {
      console.error('Error creating chat:', error);
      res.status(500).json({ error: 'Failed to create chat' });
    }
  });

  // Get user chats
  app.get('/api/chats/:userId', requireAuth, async (req, res) => {
    try {
      const userId = req.params.userId === 'currentUser' ? req.session.userId : req.params.userId;
      const chats = await storage.getUserChats(userId);
      res.json(chats);
    } catch (error) {
      console.error('Error fetching chats:', error);
      res.status(500).json({ error: 'Failed to fetch chats' });
    }
  });

  // Get chat messages
  app.get('/api/chats/:chatId/messages', requireAuth, async (req, res) => {
    try {
      const { chatId } = req.params;
      const { limit = '50', offset = '0' } = req.query;
      
      const messages = await storage.getChatMessages(
        chatId, 
        parseInt(limit as string), 
        parseInt(offset as string)
      );
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch messages' });
    }
  });

  // Mark messages as read
  app.post('/api/chats/:chatId/read', requireAuth, async (req, res) => {
    try {
      const { chatId } = req.params;
      const { userId } = req.body;
      
      await storage.markMessagesAsRead(chatId, userId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to mark messages as read' });
    }
  });


  return httpServer;
}
